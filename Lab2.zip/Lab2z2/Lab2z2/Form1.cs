﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2z2
{
    public partial class Form1 : Form
    {
        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked==true)
            {
                textBox1.Font = new Font(textBox1.Font, textBox1.Font.Style | FontStyle.Bold);
            }
            if (checkBox2.Checked == true)
            {
                textBox1.Font = new Font(textBox1.Font, textBox1.Font.Style | FontStyle.Italic);
            }
            if (checkBox3.Checked == true)
            {
                textBox1.Font = new Font(textBox1.Font, textBox1.Font.Style | FontStyle.Underline);
            }

            if (radioButton4.Checked)
            {
                textBox1.ForeColor = Color.Red;
            }
            if (radioButton5.Checked)
            {
                textBox1.ForeColor = Color.Blue;
            }
            if (radioButton6.Checked)
            {
                textBox1.ForeColor = Color.Orange;
            }

            if (radioButton1.Checked)
            {
                textBox1.Font = new Font(textBox1.Font.FontFamily, 10.0F);
            }
            if (radioButton2.Checked)
            {
                textBox1.Font = new Font(textBox1.Font.FontFamily, 15.0F);
            }
            if (radioButton3.Checked)
            {
                textBox1.Font = new Font(textBox1.Font.FontFamily, 20.0F);
            }
        }
        public Form1()
        {
            InitializeComponent();
        }
    }
}
