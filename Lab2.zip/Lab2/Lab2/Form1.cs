﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (checkBox1.Checked)
                {
                    int WagaSt = Convert.ToInt16(textBox1.Text) - 100;
                    label4.Text = Convert.ToString(WagaSt);
                }
                if (checkBox2.Checked)
                {
                    int WagaSt = Convert.ToInt16(textBox1.Text) - 100;
                    float WagaId = WagaSt * 85 / 100;
                    label4.Text = Convert.ToString(WagaId);
                }
                if (checkBox1.Checked && checkBox2.Checked)
                {
                    int WagaSt = Convert.ToInt16(textBox1.Text) - 100;
                    float WagaId = WagaSt * 85 / 100;
                    label4.Text = Convert.ToString((WagaSt+WagaId)/2);
                }
            }
            if (radioButton2.Checked)
            {
                if (checkBox1.Checked)
                {
                    int WagaSt = Convert.ToInt16(textBox1.Text) - 100;
                    label4.Text = Convert.ToString(WagaSt);
                }
                if (checkBox2.Checked)
                {
                    int WagaSt = Convert.ToInt16(textBox1.Text) - 100;
                    float WagaId = WagaSt * 95 / 100;
                    label4.Text = Convert.ToString(WagaId);
                }
                if (checkBox1.Checked && checkBox2.Checked)
                {
                    int WagaSt = Convert.ToInt16(textBox1.Text) - 100;
                    float WagaId = WagaSt * 95 / 100;
                    label4.Text = Convert.ToString((WagaSt + WagaId) / 2);
                }
            }
        }


    }
}
